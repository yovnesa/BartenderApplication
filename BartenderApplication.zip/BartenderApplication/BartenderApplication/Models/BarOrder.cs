﻿namespace BartenderApplication.Models
{
    public class BarOrder
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public int BarMenuId { get; set; }
        public string OrderItem { get; set; }
        public double Price { get; set; }

        public BarMenu BarMenu { get; set; }
    }
}
