﻿using Microsoft.EntityFrameworkCore;

namespace BartenderApplication.Models
{
    public class BartenderApplicationDbContext : DbContext
    {
        public DbSet<BarMenu> BarMenu { get; set; }

       public DbSet<BarOrder> BarOrders { get; set; }

        public BartenderApplicationDbContext(DbContextOptions<BartenderApplicationDbContext> options) : base(options) { }


        
    }

    


}
