﻿using BartenderApplication.Models;
using BartenderApplication.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BartenderApplication.Controllers
{
    public class BarOrderController : Controller
    {
        private readonly BartenderApplicationDbContext _context;

        public BarOrderController(BartenderApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Orders()
        {
            var orders = _context.BarOrders.ToList();
            if (orders == null || !orders.Any())
            {
                // Log or handle the case where the menu is empty
                Console.WriteLine("No orders items found.");
            }
            else
            {
                Console.WriteLine("All good");
            }
            return View(orders);
        }

        public IActionResult CreateOrder(int barMenuId)
        {
            var barMenuItem = _context.BarMenu.Find(barMenuId);
            if (barMenuItem == null)
            {
                return NotFound();
            }

            var viewModel = new BarOrderViewModel
            {
                BarMenuId = barMenuItem.Id,
                MenuItemName = barMenuItem.Name,
                MenuItemPrice = barMenuItem.Price
            };

            return View(viewModel);
        }

        [HttpPost]
        public IActionResult CreateOrder(BarOrderViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var customerOrder = new BarOrder
                {
                    BarMenuId = viewModel.BarMenuId,
                    OrderItem = viewModel.MenuItemName,
                    Price = viewModel.MenuItemPrice,
                    CustomerName = viewModel.CustomerName
                };

                _context.BarOrders.Add(customerOrder);
                _context.SaveChanges();

                return RedirectToAction("Orders");
            }

            return View(viewModel);
        }
    }
}
