﻿using BartenderApplication.Models;
using Microsoft.AspNetCore.Mvc;

namespace BartenderApplication.Controllers
{
    public class BarMenuController : Controller
    {
        private readonly BartenderApplicationDbContext _context;

        public BarMenuController(BartenderApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Menu()
        {
            var menu = _context.BarMenu.ToList();
            if (menu == null || !menu.Any())
            {
                // Log or handle the case where the menu is empty
                Console.WriteLine("No menu items found.");
            }
            else
            {
                Console.WriteLine("All good");
            }
            return View(menu);
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
