﻿namespace BartenderApplication.ViewModels
{
    public class BarOrderViewModel
    {
        public int BarMenuId { get; set; }
        public string MenuItemName { get; set; }
        public double MenuItemPrice { get; set; }
        public string CustomerName { get; set; }
    }
}
