using BartenderApplication.Models;
using Microsoft.EntityFrameworkCore;

namespace BartenderApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            builder.Services.AddDbContext<BartenderApplicationDbContext>(options =>
                options.UseInMemoryDatabase("BartenderApplicationDb"));

            var app = builder.Build();

            // Seed the database
            SeedDatabase(app);

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }

        private static void SeedDatabase(IHost app)
        {
            using (var scope = app.Services.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<BartenderApplicationDbContext>();
                context.Database.EnsureCreated();

                // Check if the database is already seeded
                if (!context.BarMenu.Any())
                {
                    context.BarMenu.AddRange(
                        new BarMenu { Id = 1, Name = "Margarita", Description = "A classic cocktail made with tequila, lime juice, and triple sec", Price = 12 },
                        new BarMenu { Id = 2, Name = "Mojito", Description = "A refreshing drink with rum, mint, lime, sugar, and soda water", Price = 9.5 },
                        new BarMenu { Id = 3, Name = "Old Fashioned", Description = "A timeless cocktail with bourbon or rye whiskey, sugar, bitters, and a twist of citrus", Price = 15 },
                        new BarMenu { Id = 4, Name = "Cosmopolitan", Description = "A stylish drink made with vodka, triple sec, cranberry juice, and lime juice", Price = 12.6 },
                        new BarMenu { Id = 5, Name = "Martini", Description = "A sophisticated cocktail with gin or vodka and dry vermouth, garnished with an olive or lemon twist", Price = 16.8 },
                        new BarMenu { Id = 6, Name = "Pi�a Colada", Description = "A tropical blend of rum, coconut cream, and pineapple juice", Price = 12 },
                        new BarMenu { Id = 7, Name = "Whiskey Sour", Description = "A tangy mix of whiskey, lemon juice, and sugar, often with a dash of egg white", Price = 10 }
                    );
                    context.SaveChanges();
                }
            }
        }
    }
}