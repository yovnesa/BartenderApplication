﻿using BartenderApplication.Models;
using BartenderApplication.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace BartenderApplication.Controllers
{
    public class BarOrderController : Controller
    {
        private readonly BartenderApplicationDbContext _context;

        public BarOrderController(BartenderApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Orders()
        {
            var orders = _context.BarOrders.ToList();
            if (orders == null || !orders.Any())
            {
                // Log or handle the case where the menu is empty
                Console.WriteLine("No orders items found.");
            }
            else
            {
                Console.WriteLine("All good");
            }
            return View(orders);
        }

        public IActionResult CreateOrder(int barMenuId)
        {
            var barMenuItem = _context.BarMenu.Find(barMenuId);
            if (barMenuItem == null)
            {
                return RedirectToAction("Menu", "BarMenu");
            }

            var viewModel = new BarOrderViewModel
            {
                BarMenuId = barMenuItem.Id,
                MenuItemName = barMenuItem.Name,
                MenuItemPrice = barMenuItem.Price
            };

            return View(viewModel);
        }

        [HttpPost]
        public IActionResult CreateOrder(BarOrderViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var customerOrder = new BarOrder
                {
                    BarMenuId = viewModel.BarMenuId,
                    OrderItem = viewModel.MenuItemName,
                    Price = viewModel.MenuItemPrice,
                    CustomerName = viewModel.CustomerName,
                    IsReady = viewModel.IsReady = false
                    
                };

                _context.BarOrders.Add(customerOrder);
                _context.SaveChanges();

                return RedirectToAction("Orders");
            }

            return View(viewModel);
        }


        public IActionResult EditStatus(int? id)
        {

            if (id != null)
            {
                var IdInOrders = _context.BarOrders.Find(id);

                if(IdInOrders.IsReady != true)
                {
                    IdInOrders.IsReady = true;
                }
                else
                {
                    IdInOrders.IsReady = false;
                }
                _context.SaveChanges();
            }

            return RedirectToAction("Orders");
        }

        public IActionResult DeleteOrder(int id)
        {

            var orderInDb = _context.BarOrders.SingleOrDefault(BarOrder => BarOrder.Id == id);
            _context.BarOrders.Remove(orderInDb);
            _context.SaveChanges();

            return RedirectToAction("Orders");
        }
    }
}
